module.exports = require("./inotify.node");

