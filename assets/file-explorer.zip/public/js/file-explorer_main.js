//####assets/js/backbone.slickeditor.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// This is a copy of SlickGrid default text editor, adapted to handle
// Backbone.js models. There is sadly no way to just override the loadValue
// function.
function BackboneTextEditor(args) {
    var $input;
    var defaultValue;
    var scope = this;

    this.init = function () {
        $input = $("<INPUT type=text class='editor-text' />")
            .appendTo(args.container)
            .bind("keydown.nav", function (e) {
                if (e.keyCode === $.ui.keyCode.LEFT || e.keyCode === $.ui.keyCode.RIGHT) {
                    e.stopImmediatePropagation();
                }
            })
            .focus()
            .select();
    };

    this.destroy = function () {
        $input.remove();
    };

    this.focus = function () {
        $input.focus();
    };

    this.getValue = function () {
        return $input.val();
    };

    this.setValue = function (val) {
        $input.val(val);
    };

    this.loadValue = function (item) {
        // Read the current value from Backbone.
        defaultValue = item.get(args.column.field) || "";
        $input.val(defaultValue);
        $input[0].defaultValue = defaultValue;
        $input.select();
    };

    this.serializeValue = function () {
        return $input.val();
    };

    this.applyValue = function (item, state) {
        // Use Backbone to change the value.
        item.set(args.column.field, state);
        item.save();
    };

    this.isValueChanged = function () {
        return (!($input.val() == "" && defaultValue == null)) && ($input.val() != defaultValue);
    };

    this.validate = function () {
        if (args.column.validator) {
            var validationResults = args.column.validator($input.val());
            if (!validationResults.valid) {
                return validationResults;
            }
        }

        return {
            valid: true,
            msg: null
        };
    };

    this.init();
}




/* ******** */

//####assets/js/model.options.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var OptionItem = Backbone.Model.extend({ });

var Options = Backbone.Collection.extend({
    localStorage: new Backbone.LocalStorage("FileExplorer-Options"),
    model: OptionItem,

    // Initialize the option
    initOption: function (opt, val) {
        if (!this.findWhere({ opt: opt })) {
            var m = new OptionItem(
                { opt: opt, val: val}
            );

            this.add(m);
            m.save();
        }
    },

    toggleOption: function (opt) {
        var m;
        if ((m  = this.findWhere({ opt: opt }))) {
            var v = m.get("val");
            m.set("val", !v);
            m.save();
        }
    },

    getOption: function (opt) {
        return this.findWhere({ opt: opt });
    },

    getOptionValue: function (opt) {
        return this.getOption(opt).get("val");
    },

    setOptionValue: function (opt, nval) {
        var m;
        if ((m = this.findWhere({ opt: opt }))) {
            var v = m.get("val");
            m.set("val", nval);
            m.save();
        }
    },

    activate: function () {
        this.forEach(function (opt) {
            opt.trigger("change", opt);
        });
    }
});


/* ******** */

//####assets/js/model.fs.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var File = Backbone.Model.extend({
    idAttribute: "name",

    sync: function (method, model, options) {
        var self = this;
        var errorCb = options.error;

        // Fall back to the default apply method for read requests.
        if (method == "read")
            return Backbone.sync.apply(this, arguments);

        // The following methods go through special endpoints.

        if (method == "delete") {
            Backbone.ajax(_.extend(options, {
                type: "POST",
                url: "/rm?f=" + encodeURIComponent(model.get("path"))
            }));

            return;
        }

        if (method == "update") {
            // We can only handle file name changes for now.
            if (model.hasChanged("name")) {
                var from = encodeURIComponent(model.get("path"));
                var to = encodeURIComponent(model.get("name"));

                Backbone.ajax(_.extend(options, {
                    type: "POST",
                    url: "/mv?f=" + from + "&n=" + to
                }));
            }

            return;
        }

        if (method == "create") {
            // The only thing we create is a
            if (model.get("isDir")) {
                Backbone.ajax(_.extend(options, {
                    type: "POST",
                    url: "/mkdir?p=" + encodeURIComponent(model.get("path"))
                }));

                // Immediately destroy the model since it'll appear by itsef as a newly
                // created directory inside an event sent by the server side.
                model.destroy();
            }

            return;
        }

        // And those are unsupported.

        if (method == "patch") {
            throw "Method " + method + " unsupported";
        }
    }
});

var Files = Backbone.Collection.extend({
    model: File,

    url: function () {
        return "/fs/files?p=" + this._rootPath;
    },

    getItem: function (i) {
        return this.at(i);
    },

    getLength: function () {
        return this.length;
    },

    getErrors: function () {
        return this._errors;
    },

    getEvents: function () {
        return this._fileEvents;
    },

    comparator: function (m1, m2) {
        var r;

        if (m1.get(this._sortField) < m2.get(this._sortField))
            r = -1;
        else if (m2.get(this._sortField) < m1.get(this._sortField))
            r = 1;
        else
            r = 0;

        if (this._sortDesc)
            r = -r;

        return r;
    },

    // This object must be closed since it opens an event source which are
    // in limited quantity.
    close: function () {
        if (this._ev) this._ev.close();
    },

    initialize: function (options) {
        var self = this;

        this._rootPath = options.rootPath;
        this._showHidden = options.showHidden;
        this._fileEvents = new Events([], { fs: this });

        this._sock = io.connect(location.host + "/" + options.rootPath.replace(/\//g, "_"),
            { rememberTransport: false, transports: ["websocket"] });

        if (options.hasOwnProperty("sortField"))
            this._sortField = options.sortField;
        if (options.hasOwnProperty("sortDesc"))
            this._sortDesc = options.sortDesc;

        this._sock.on("create", function (ev) {
            console.log("Created: " + ev.path);
            self.add(ev, {merge: true});
        });

        this._sock.on("delete", function (ev) {
            console.log("Deleted: " + ev.path);
            self.remove(ev.name);
        });

        this._sock.on("modify", function (ev) {
            console.log("Modified: " + ev.path);
            self.get(ev.name).set(ev);
        });

        this._sock.on("rename", function (ev) {
            console.log("Renamed: " + ev.path);
            self.get(ev.oldName).set(data);
        });
    },

    parse: function (response) {
        var self = this;
        var newResponse = [];

        this._errors = new Backbone.Collection();

        _.each(response, function (respItem) {
            // Handle hidden files for the JStree layout.
            if (!self._showHidden) {
                if (respItem.name.charAt(0) != ".")
                    newResponse.push(respItem);
            }
            else newResponse.push(respItem);

            // Handle errors
            if (respItem.error)
                self._errors.add(new Backbone.Model(respItem));
        });

        return newResponse;
    },

    root: function () {
        return this._rootPath;
    }
});

/* ******** */

//####assets/js/model.events.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var Event = Backbone.Model.extend({ });

var Events = Backbone.Collection.extend({
    model: Event,

    changedUidGidTemplate: _.template(
        "File <%= name %> owner/group changed from "
            + "<%= oldUsername %>[<%= oldUid %>]/<%= oldGroupname %>[<%= oldGid %>]"
            + " to "
            + "<%= newUsername %>[<%= newUid %>]/<%= newGroupname %>[<%= newGid %>]"),

    getItem: function (i) {
        return this.at(i);
    },

    getLength: function () {
        return this.length;
    },

    _onFileChanged: function (m, opts) {
        var self = this;
        var pa = m.previousAttributes();

        if (m.hasChanged("size")) {
            var newSize, oldSize;

            newSize = Humanize.filesizeformat(m.get("size"));
            oldSize = Humanize.filesizeformat(pa["size"]);

            self.add(new Event({
                type: "change",
                attr: "size",
                file: m.get("path"),
                time: moment().format("HH:mm:ss"),
                msg: "Size change: " + m.get("path") + ", from: " + oldSize + " to " + newSize
            }));
        }

        if (m.hasChanged("name")) {
            var newName, oldName;

            newName = m.get("name");
            oldName = pa["name"];

            self.add(new Event({
                type: "change",
                attr: "name",
                file: m.get("path"),
                time: moment().format("HH:mm:ss"),
                msg: "Name change from: " + oldName + " to: " + newName
            }));
        }

        if (m.hasChanged("uid")
            || m.hasChanged("gid")
            || m.hasChanged("username")
            || m.hasChanged("groupname")) {
            var p = {};

            p.newGid = m.get("gid");
            p.oldGid = pa["gid"];
            p.newUid = m.get("uid");
            p.oldUid = pa["uid"];
            p.newUsername = m.get("username");
            p.oldUsername = pa["username"];
            p.newGroupname = m.get("groupname");
            p.oldGroupname = pa["groupname"];

            self.add(new Event({
                type: "change",
                file: m.get("path"),
                time: moment().format("HH:mm:ss"),
                msg: self.changedUidGidTemplate(p)
            }));
        }
    },

    _onFileCreated: function (m, col, opts) {
        var self = this;

        self.add(new Event({
            type: "create",
            file: m.get("path"),
            time: moment().format("HH:mm:ss"),
            msg: "Created: " + m.get("path")
        }));
    },

    _onFileDeleted: function (m, col, opts) {
        var self = this;

        self.add(new Event({
            type: "delete",
            file: m.get("path"),
            time: moment().format("HH:mm:ss"),
            msg: "Deleted: " + m.get("path")
        }));
    },

    initialize: function (models, opts) {
        var self = this;

        self._fs = opts.fs;

        self._fs.on("change", function (m, opts) {
            self._onFileChanged.apply(self, [m, opts])
        });

        self._fs.on("add", function (m, col, opts) {
            self._onFileCreated.apply(self, [m, col, opts]);
        });

        self._fs.on("remove", function (m, col, opts) {
            self._onFileDeleted.apply(self, [m, col, opts]);
        });
    }
});

/* ******** */

//####assets/js/popup.view.confirm.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var ConfirmPopup = Backbone.View.extend({

    _action: null,
    _files: null,
    _btnOkId: _.uniqueId("confirmPopup"),
    _btnCancelId: _.uniqueId("confirmPopup"),
    _chkConfirmId: _.uniqueId("confirmPopup"),

    // This is the the title of the dialog, set this in the constructor.
    title: "Default title",

    // This is the name of the option to be used to disable confirmation
    // for this specific dialog.
    confirmOption: "",

    // The text accompaying the checkbox.
    confirmOptionText: "",

    initialize: function (options) {
        var self = this;

        self._context = options.context;
        self._buttons = options.buttons;
        self._confirm = options.confirm || function () {};
        self._cancel = options.cancel || function () {};
        self._options = options.options;
        self._showClose = options.showClose || false;
    },

    _onPopupOpened: function () {
        var self = this;

        _.each(self._buttons, function (btnData) {
            $(document.getElementById(btnData.id)).bind("click", function () {
                if (btnData.action)
                    btnData.action.apply(self._context);

                w2popup.close();
            });
        });

        if (self._confirm) {
            $(document.getElementById(self._chkConfirmId)).bind("change", function () {
                self._options.setOptionValue("confirmDelete", $(this).prop("checked"));
            });
        }
    },

    renderBody: function ($body) {},

    render: function () {
        var self = this;
        var body, buttons, btnOk, btnCancel, chkConfirm, main;
        var filelist = $("<ul></ul>");

        // Body
        main = $("<div></div>");

        body = $("<div></div>").attr("rel", "body");

        this.renderBody(body);

        // Buttons.
        if (self.confirmOption)
            chkConfirm = $("<input></input>")
                .attr("id", self._chkConfirmId)
                .attr("type", "checkbox")
                .attr("checked", self._options.getOptionValue(self.confirmOption))
                .add($("<label></label>")
                    .attr("for", self._chkConfirmId)
                    .text(self.confirmOptionText));

        _.each(self._buttons, function (btnData) {
            btnData.id = _.uniqueId("confirmDialog");
            btnData.$btn = $("<button></button>")
                .attr("class", "btn")
                .attr("id", btnData.id)
                .text(btnData.caption);
        });

        buttons = $("<div></div>")
            .attr("rel", "buttons");

        if (self.confirmOption)
            buttons.append(chkConfirm);

        _.each(self._buttons, function (btnData) {
            buttons.append(btnData.$btn);
        });

        body.append(filelist);
        main.append([body, buttons]);

        main.w2popup({
            title: self.title,
            modal: true,
            showClose: self._showClose,

            onOpen: function (event) {
                event.onComplete = function () {
                    self._onPopupOpened.apply(self);
                }
            }
        });
    }
});


/* ******** */

//####assets/js/popup.view.message.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var MessagePopup = Backbone.View.extend({

    _action: null,
    _files: null,
    _btnOkId: _.uniqueId("confirmPopup"),

    // This is the the title of the dialog, set this in the constructor.
    title: "Default title",

    // This is the name of the option to be used to disable confirmation
    // for this specific dialog.
    confirmOption: "",

    // The text accompaying the checkbox.
    confirmOptionText: "",

    initialize: function (options) {
        var self = this;

        self._files = options.files;
        self._context = options.context;
        self._options = options.options;
    },

    renderBody: function ($body) {},

    _onPopupOpened: function () {
        var self = this;

        $(document.getElementById(self._btnOkId)).bind("click", function () {
            w2popup.close();
        });
    },

    render: function () {
        var self = this;
        var body, buttons, btnOk, main;
        var filelist = $("<ul></ul>");

        // Body
        main = $("<div></div>");

        body = $("<div></div>").attr("rel", "body");

        this.renderBody(body);

        btnOk = $("<button></button>")
            .attr("id", self._btnOkId)
            .attr("class", "btn")
            .text("OK");

        buttons = $("<div></div>")
            .attr("rel", "buttons")
            .append(btnOk)

        body.append(filelist);
        main.append([body, buttons]);

        main.w2popup({
            title: self.title,
            modal: true,
            onOpen: function (event) {
                event.onComplete = function () {
                    self._onPopupOpened.apply(self);
                }
            }
        });
    }
});

/* ******** */

//####assets/js/popup.view.delete.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var DeletePopup = ConfirmPopup.extend({

    initialize: function (options) {
        options.buttons = [
            {
                caption: "Yes",
                action: options.confirm
            },
            {
                caption: "No"
            }
        ];

        ConfirmPopup.prototype.initialize.apply(this, [options]);

        this._files = options.files;
        this.title = "Confirm file removal";
        this.confirmOption = "confirmDelete";
        this.confirmOptionText = "Always confirm removal";
    },

    renderBody: function ($body) {
        var self = this;
        var filelist = $("<ul></ul>");

        $body.text("The following files will be removed:");

        _.each(self._files, function (file) {
            filelist.append($("<li></li>").text(file.get("name")));
        });

        $body.append(filelist);
    }
});

/* ******** */

//####assets/js/popup.view.rename.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var RenamePopup = ConfirmPopup.extend({

    initialize: function (options) {
        options.buttons = [
            {
                caption: "Yes",
                action: options.confirm
            },
            {
                caption: "No"
            }
        ];

        ConfirmPopup.prototype.initialize.apply(this, [options]);

        this._to = options.to;
        this._from = options.from;

        this.title = "Confirm rename";
        this.confirmOption = "confirmRename";
        this.confirmOptionText = "Always confirm rename";
    },

    renderBody: function ($body) {
        var self = this;
        var filelist = $("<ul></ul>");

        $body.text("The following file will be renamed:");
        $body.append(
            $("<div></div>").text(this._from + " to " + this._to));

        _.each(self._files, function (file) {
            filelist.append($("<li></li>").text(file.get("name")));
        });

        $body.append(filelist);
    }
});


/* ******** */

//####assets/js/popup.view.errormsg.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var ErrorMessagePopup = MessagePopup.extend({

    initialize: function (options) {
        ConfirmPopup.prototype.initialize.apply(this, [options]);

        this.title = "Error";
        this._serverMsg = options.serverMsg;
        this._msg = options.msg
    },

    renderBody: function ($body) {
        $body.append(
            $("<div></div>").text(this._msg));
        $body.append(
            $("<pre></pre>").text(this._serverMsg));
    }
});

/* ******** */

//####assets/js/popup.view.stopped.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var StoppedPopup = ConfirmPopup.extend({

    initialize: function (options) {
        options.showClose = false;

        ConfirmPopup.prototype.initialize.apply(this, [options]);

        this.title = "Lost backend";
    },

    renderBody: function ($body) {
        $body.text("Communication with the backend was lost.");
    }

});


/* ******** */

//####assets/js/overlay.view.columns.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var ColumnsOverlay = Backbone.View.extend({

    initialize: function (options) {
        this._options = options.options;
    },

    _onColumnCheckClick: function (colId, checked) {
        var curVal = this._options.getOptionValue("columns");

        if (checked)
            this._options.setOptionValue("columns", _.uniq(curVal.concat(colId)));
        else
            this._options.setOptionValue("columns", _.without(curVal, colId));
    },

    render: function () {
        var curVal = this._options.getOptionValue("columns");
        var self = this;
        var overlayEl;
        var overlayDiv = $("<div></div>");
        var overlayUl = $("<ul></ul>");

        overlayEl = this.$el;
        overlayDiv.css("margin", "1em");
        overlayDiv.append(overlayUl);

        _.each(FileListView.getAvailableColumns(), function (colId) {
            var li, chk, lbl, checked;

            checked = _.contains(curVal, colId);

            li = $("<li></li>");
            chk = $("<input></input>")
                .attr("type", "checkbox")
                .attr("name", colId);
            lbl = $("<label></label>")
                .attr("for", colId)
                .text(FileListView.getColumnName(colId));

            if (checked)
                chk.attr("checked", "checked");

            li.append(chk.add(lbl));

            chk.on("change", function () {
                self._onColumnCheckClick.apply(self, [colId, $(this).prop("checked")]);
            });

            overlayUl.append(li);
        });

        overlayEl.append(overlayDiv);
    }
});



/* ******** */

//####assets/js/overlay.view.options.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var OptionsOverlay = Backbone.View.extend({

    initialize: function (options) {
        this._options = options.options;
    },

    render: function () {
        var self = this;
        var ul, optHiddenLi, optConfirmRemoveLi,
            optConfirmRenameLi, overlayDiv;

        overlayDiv = this.$el;
        overlayDiv.css("margin", "1em");

        ul = $("<ul></ul>");
        optHiddenLi = $("<li></li>")
            .append(
                $("<input></input>")
                    .attr("type", "checkbox")
                    .attr("name", "optShowHidden")
                    .attr("checked", self._options.getOptionValue("showHidden"))
                    .on("change", function () {
                        self._options.setOptionValue("showHidden", $(this).prop("checked"));
                    }))
            .append(
                $("<label></label>")
                    .attr("for", "optShowHidden")
                    .text("Show hidden files"));
        optConfirmRemoveLi = $("<li></li>")
            .append(
                $("<input></input>")
                    .attr("type", "checkbox")
                    .attr("name", "optConfirmDelete")
                    .attr("checked", self._options.getOptionValue("confirmDelete"))
                    .on("change", function () {
                        self._options.setOptionValue("confirmDelete", $(this).prop("checked"));
                    }))
            .append(
                $("<label></label>")
                    .attr("for", "optConfirmDelete")
                    .text("Confirm removal"));
        optConfirmRenameLi = $("<li></li>")
            .append(
                $("<input></input>")
                    .attr("type", "checkbox")
                    .attr("name", "optConfirmRename")
                    .attr("checked", self._options.getOptionValue("confirmRename"))
                    .on("change", function () {
                        self._options.setOptionValue("confirmRename", $(this).prop("checked"));
                    }))
            .append(
                $("<label></label>")
                    .attr("for", "optConfirmRename")
                    .text("Confirm rename"));

        overlayDiv.append([
            optHiddenLi,
            optConfirmRemoveLi,
            optConfirmRenameLi
        ]);
    }
});

/* ******** */

//####assets/js/overlay.view.errors.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var ErrorsOverlay = Backbone.View.extend({

    initialize: function (options) {
        this._options = options.options;
        this._errors = options.errors;
    },

    render: function () {
        var overlayEl = this.$el;
        var overlayUl = $("<ul></ul>");

        overlayEl.css("margin", "1em");

        if (this._errors && this._errors.length > 0) {
            _.each(this._errors, function (err) {
                var overlayLi = $("<li></li>").text(err.get("message"));
                overlayUl.append(overlayLi);
            });

            overlayEl.append(overlayUl);
        }
        else overlayEl.append($("<div></div>").text("No errors were registered."));
    }
});

/* ******** */

//####assets/js/overlay.view.upload.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var UploadOverlay = Backbone.View.extend({

    initialize: function (options) {
        this._options = options.options;
    },

    render: function () {
        var self = this;

        // We can refer directly to the overlay object because
        // w2ui allows for a single overlay at the time.
        var overlay = $("#w2ui-overlay");

        self._uploadDiv = $("<div></div>");
        self.$el.append(self._uploadDiv);

        self._uploadDiv
            .css("width",  overlay.innerWidth())
            .css("height", overlay.innerHeight());
        self._uploadObj = UploadView.get();

        self._uploadObj.setElement(self._uploadDiv);
        self._uploadObj.render();
    },

    hide: function () {
        this._uploadDiv.detach();
    }
});


/* ******** */

//####assets/js/view.upload.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

Dropzone.autoDiscover = false;

var UploadView = Backbone.View.extend({

        _uploadFieldId: _.uniqueId("uploadView"),
        _chkOverwriteId: _.uniqueId("uploadView"),
        _currentDir: null,
        _overwrite: false,

        _onCheckOverwriteChange: function (chkBox) {
            var self = this;
            self._overwrite = $(chkBox).prop("checked");
        },

        setDirectory: function (newDir) {
            var self = this;

            self._currentDir = newDir;
        },

        render: function () {
            var self = this;

            self.$el.append(self._chkDiv.add(self._div));

            self._div
                .css("width", "100%")
                .css("height", self.$el.innerHeight() - self._chkDiv.outerHeight(true));

            // Reinitialize the 'overwrite' checkbox to false.
            self._chkBox.prop("checked", false);

            self._chkBox.bind("change", function () {
                self._onCheckOverwriteChange.apply(self, [this]);
            });
        },

        initialize: function () {
            var self = this;

            self._divMsg = $("<span></span>")
                .attr("class", "dz-message")
                .text("Drop files to upload or click for a dialog box");

            self._div = $("<div></div>")
                .attr("id", self._uploadFieldId)
                .attr("class", "dropzone")
                .css("overflow", "auto")
                .append(self._divMsg);

            // This quirky CSS should perhaps be moved in a .css file.

            self._chkBox = $("<input></input>")
                .attr("id", self._chkOverwriteId)
                .attr("type", "checkbox")
                .add($("<span></span>")
                    .css("padding-left", "5px")
                    .css("vertical-align", "top")
                    .text("Overwrite files?"));

            self._chkDiv = $("<div></div>")
                .css("padding", "10px")
                .append(self._chkBox);

            self._dz = new Dropzone(self._div.get(0), {
                url: "/up",
                maxFilesize: 1000000,
                addRemoveLinks: true,

                init: function () {
                    this.on("processing", function () {
                        var p = encodeURIComponent(self._currentDir.get("path"));
                        var o = self._overwrite ? "1" : "0";
                        this.options.url = "/up?p=" + p + "&o=" + o;
                    });
                }
            });
        }
    }, {
        get: function () {
            if (!UploadView._uploadObj)
                UploadView._uploadObj = new UploadView();

            return UploadView._uploadObj;
        }
    }
);



/* ******** */

//####assets/js/view.dirtree.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var DirTreeView = Backbone.View.extend({

    _openDirParts: [],
    _openCurrent: null,
    _hasWarnedAboutRunningAsRoot: false,
    _rootTooltip: null,

    initialize: function (options) {
        var self = this;

        this._options = options.options;

        self.$el.jstree({
            "core" : {
                "check_callback" : function (operation, node, node_parent, node_position, more) {
                    return operation === "rename_node";
                },
                "data" : {
                    "url" : function (node) {
                        var showHidden = self._options.getOptionValue("showHidden") ? 1 : 0;

                        if (node.id == "#")
                            return "/fs/dirs?a=jstree";
                        else
                            return "/fs/dirs?h=" + showHidden + "&a=jstree&p=" + node.data.path
                    },
                    "data" : function (node) {
                        return { id: node.id };
                    }
                }
            },
            "types": {
                "no-access": {
                    "icon": "./icons/_noaccess.png"
                },
                "broken-symlink": {
                    "icon": "./icons/_noaccess.png"
                },
                "symlink": {
                    "icon": "./icons/_symlink.png"
                }
            },
            "ui": {
                "initially_select" : [ "/" ]
            },
            "plugins" : [ "search", "types" ]

        }).on("select_node.jstree",
            function (ev, obj) {
                if (obj.node.type == "no-access") {
                    if (!self._hasWarnedAboutRunningAsRoot)
                    {
                        var chkId = _.uniqueId("opentip");
                        var targetTreeItem = $(self.$el.jstree().get_node(obj.node.id, true));
                        var targetTreeIcon = $(targetTreeItem.children()[1]).children([0]);

                        self._rootTooltip = new Opentip(self.$el, {
                            title: "Having access error?",
                            target: targetTreeIcon,
                            style: "warnPopup",
                            targetJoint: "center right",
                            tipJoint: "top right",
                            showOn: null
                        });
                        self._rootTooltip.setContent(
                            "<p>Unless File Explorer runs as root, you won't be able to all the files and " +
                            "directories on your device. If you have one of the 'su' apps installed, enable the " +
                            "'Run as root' option above before starting the service.</p>" +
                            "<p>If you're using the AOSP emulator run the following on your computer and don't " +
                            "make use of the 'Start the service' button.</p>" +
                            "<pre>$ adb shell 'cd /data/user/0/com.opersys.fileexplorer/files &amp;&amp; ./node ./app.js'</pre>" +
                            '<input id="' + chkId + '" type="checkbox" />' +
                            '<label for="' + chkId + '">Don\'t show this message again</label>'
                        );

                        self._rootTooltip.show();

                        $(document.getElementById(chkId)).on("click", function () {
                            self._rootTooltip.hide();
                            self._hasWarnedAboutRunningAsRoot = true;
                        });
                    }
                    else rootTooltip.hide();
                }

                self.trigger("dirtreeview:ondirectoryselected", new File(obj.node.data));
            }
        ).on("ready.jstree",
            function () {
                if (self._options.getOptionValue("lastDirectory"))
                    self.openDirectory(self._options.getOptionValue("lastDirectory"));
            }
        ).on("load_node.jstree",
            function (node, status) {
                status.node.children.forEach(function (nodeId) {
                        var newName, node = self.$el.jstree("get_node", nodeId);

                        if (node.type === "symlink") {
                            if (node.data != null && node.data.link) {
                                newName = node.text + " [-> " + node.data.link.path + "]";
                            }

                            self.$el.jstree("rename_node", node, newName);
                        }
                    }
                );
            }
        );
    },

    _endOpenDirectory: function (done) {
        var self = this;

        console.log("Ending openDirectory at: " + self._openCurrent);

        // Activate the last node.
        if (!done)
            self.$el.jstree("select_node", self._openCurrent);

        self._openCurrent = null;
        self._openDirParts = [];
    },

    _doOpenDirectory: function () {
        var self = this;

        if (self.$el.jstree("get_node", self._openCurrent)) {

            console.log("Will try to load: " + self._openCurrent);

            self.$el.jstree("load_node", self._openCurrent, function () {
                console.log("Loaded: " + self._openCurrent);

                self.$el.jstree("open_node", self._openCurrent);

                var newPart = self._openDirParts.shift();

                if (newPart) {
                    if (/\/$/.test(self._openCurrent))
                        self._openCurrent += newPart;
                    else
                        self._openCurrent += ("/" + newPart);

                    self._doOpenDirectory();
                }
                else
                    self._endOpenDirectory(false);
            });

            return;
        }

        self._endOpenDirectory(true);
    },

    openDirectory: function (dir) {
        var self = this;

        console.log("Opening directory: " + dir);

        self._openDirParts = dir.split("/");
        self._openDirParts.shift();
        self._openCurrent = "/";

        self._doOpenDirectory();
    },

    // Refetch the current directory.
    refresh: function () {
        this.$el.jstree("refresh");
    }
});

/* ******** */

//####assets/js/view.filelist.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var FileListView = Backbone.View.extend({

        _filesOptions: {
            formatterFactory: {
                getFormatter: function () {
                    return function (row, cell, value, col, data) {

                        if (col.field == "ctime" || col.field == "mtime" || col.field == "atime")
                            return moment(data.get(col.field)).format("MMM Do HH:mm");
                        if (col.field == "name" && data.get("isSymlink"))
                            return data.get(col.field) + " [-> " + data.get("link").path + "]";
                        else
                            return data.get(col.field);
                    };
                }
            },

            enableColumnReorder: true,
            enableCellNavigation: true,
            forceFitColumns: true,
            enableAsyncPostRender: true,
            editable: true,
            autoEdit: false
        },

        // This is the actual list of columns passed to SlickGrid.
        _columns: [],

        _dateTimeFormatter: function (row, cell, value, columnDef, file) {
            return moment(file.get(columnDef.field)).format("MMM Do HH:mm");
        },

        _sizeFormatter: function (row, cell, value, columnDef, file) {
            return Humanize.filesizeformat(file.get(columnDef.field));
        },

        _iconFormatter: function (row, cell, value, columnDef, file) {
            return "...";
        },

        _initializeGrid: function () {
            var self = this;

            self._filesGrid = new Slick.Grid(self.$el, self._files, self._columns,
                _.extend({ editCommandHandler: self._getEditCommandHandler() }, self._filesOptions));

            self._filesGrid.setSelectionModel(new Slick.RowSelectionModel());

            // Wire grid events.
            self._filesGrid.onColumnsReordered.subscribe(function (e, args) {
                self._onColumnReordered.apply(self, [args]);
            });

            self._filesGrid.onSort.subscribe(function (e, args) {
                self._onSort.apply(self, [args]);
            });

            self._filesGrid.onDblClick.subscribe(function (e, args) {
                self._onDblClick.apply(self, [args]);
            });

            self._filesGrid.getSelectionModel().onSelectedRangesChanged.subscribe(function (e, args) {
                self._onSelectedRangeChanged.apply(self, [args]);
            });

            self._updateColumnsFormatter();
        },

        _updateColumnsFormatter: function () {
            var self = this;

            if (self._filesGrid.getColumnIndex("size") != null) {
                self._columns[self._filesGrid.getColumnIndex("size")].formatter = function () {
                    return self._sizeFormatter.apply(self, arguments);
                };
            }

            if (self._filesGrid.getColumnIndex("icon") != null) {
                self._columns[self._filesGrid.getColumnIndex("icon")].formatter = function () {
                    return self._iconFormatter.apply(self, arguments);
                };
            }

            var dateTimeCols = ["atime", "ctime", "mtime"];

            _.each(dateTimeCols, function (dtCol) {
                if (self._filesGrid.getColumnIndex(dtCol) != null) {
                    self._columns[self._filesGrid.getColumnIndex(dtCol)].formatter = function () {
                        return self._dateTimeFormatter.apply(self, arguments);
                    };
                }
            });
        },

        _onFilesAdd: function (model) {
            var self = this;

            self._filesGrid.invalidate();
            self._filesGrid.updateRowCount();

            // Immediately resize the canvas.
            self._filesGrid.resizeCanvas();

            self._filesGrid.render();

            // If the new model is the result of a directory creation, immediately
            // make the corresponding name editable.
            if (model.get("isMkdir")) {
                var rowNo = self._files.indexOf(model);
                var colNo = self.getColumnPos("name");

                if (colNo > 0) {
                    self._filesGrid.setActiveCell(rowNo, colNo);
                    self._filesGrid.editActiveCell();
                }
            }
        },

        _onFilesRemove: function () {
            var self = this;

            self._filesGrid.invalidate();
            self._filesGrid.updateRowCount();

            // Immediately resize the canvas.
            self._filesGrid.resizeCanvas();

            self._filesGrid.render();
        },

        _onFilesChange: function () {
            var self = this;

            self._filesGrid.invalidate();
            self._filesGrid.updateRowCount();

            self._filesGrid.render();
        },

        // Edit command handler.
        _getEditCommandHandler: function () {
            var self = this;

            return function (model, column, editCommand) {
                if (self._options.getOptionValue("confirmRename")) {
                    new RenamePopup({
                        from: model.get("name"),
                        to: editCommand.serializedValue,
                        options: self._options,
                        cancel: function () {
                            editCommand.undo();
                        },
                        confirm: function () {
                            editCommand.execute();
                        }
                    }).render();
                }
                else editCommand.execute();
            }
        },

        // Grid events.

        _onColumnReordered: function (args) {
            var self = this;
            var cols = self._filesGrid.getColumns();
            var colIds = _.map(cols, function (colData) {
                return colData.id;
            });

            this._options.setOptionValue("columns", colIds);
            self._updateColumnsFormatter();
        },

        _onSort: function (args) {
            var self = this;

            // Save the last sort options so they can be restored.
            self._options.setOptionValue("sortInfo", {
                field: args.sortCol.field,
                desc: (!args.sortAsc)
            });
        },

        _onDblClick: function (args) {
            var dataItem = this._filesGrid.getDataItem(args.row);
            //this.trigger("filelistview:ondoubleclickaction", dataItem)
        },

        _onSelectedRangeChanged: function (args) {
            var self = this;
            var files = [];

            _.each(args, function (range) {
                for (var r = range.fromRow; r <= range.toRow; r++)
                    files.push(self._filesGrid.getDataItem(r));
            });

            self.trigger("filelistview:onfilesselected", files);
        },

        // Other events.

        _onDirectoryFetched: function () {
            var self = this;

            self.trigger("filelistview:ondirectoryloaded", self._currentDir);

            if (!self._filesGrid)
                self._initializeGrid();

            if (self._files.getErrors().length > 0) {
                self._files.getErrors().each(function (m) {
                    self.trigger("filelistview:onfileserror", m);
                });
            }

            self._filesGrid.setData(self._files);
            self._filesGrid.render();
        },

        // Methods.

        createDirectory: function () {
            var self = this;
            var newdir = new File();
            var idx = 0;
            var actualName, defaultName = "New Directory";

            actualName = defaultName;

            // Try to find a safe filename.
            while (self._files.get(actualName) != null) {
                actualName = defaultName + "." + ++idx;
            }

            newdir.set("path", self._currentDir.get("path") + "/" + actualName);
            newdir.set("isDir", true);

            self._files.add(newdir);

            newdir.save();
        },

        clearSelection: function () {
            this._filesGrid.setSelectedRows([]);
        },

        getSelectedFiles: function () {
            var self = this;

            return _.map(this._filesGrid.getSelectedRows(), function (r) {
                return self._filesGrid.getDataItem(r);
            });
        },

        getColumnPos: function (colId) {
            var self = this;
            var colMap = _.map(this._columns, function (col) {
                return col.id;
            });

            return _.indexOf(colMap, colId);
        },

        setColumns: function (columnsIds) {
            var self = this;
            var cols = _.map(columnsIds, function (colId) {
                return FileListView._availableColumns[colId];
            });

            self._columns = cols;

            if (self._filesGrid) {
                self._filesGrid.setColumns(cols);
                self._updateColumnsFormatter();
                self._filesGrid.render();
            }
        },

        setDirectory: function (files, directory) {
            var self = this;

            self._files = files;
            self._currentDir = directory;

            if (!self._filesGrid)
                self._initializeGrid();

            self._filesGrid.setData(self._files);
            self._filesGrid.render();

            self._files.on("add", function (model) {
                self._onFilesAdd.apply(self, [model]);
            });

            self._files.on("remove", function () {
                self._onFilesRemove.apply(self);
            });

            self._files.on("change", function () {
                self._onFilesChange.apply(self);
            });

        },

        resize: function () {
            if (this._filesGrid)
                this._filesGrid.resizeCanvas();
        },

        // Refetch the current directoy.
        refresh: function () {
            this.setDirectory(this._files, this._currentDir);
        },

        initialize: function (options) {
            var self = this;

            self._options = options.options;

            // Option traps
            self._options.getOption("columns").on("change", function () {
                var newCols = self._options.getOptionValue("columns");
                self.setColumns(newCols);
            });
        }
    },

    // Static methods.

    {
        getColumnName: function (colId) {
            return FileListView._availableColumns[colId].optionName;
        },

        getAvailableColumns: function () {
            return _.keys(FileListView._availableColumns);
        },

        _availableColumns: {
            "icon": {
                optionName: "Icon", id: "icon", name: "&nbsp;", field: "icon",
                sortable: true, minWidth: 25, maxWidth: 25, renderOnResize: true,
                asyncPostRender: function (cellNode, row, file, colDef) {
                    $(cellNode).empty().append($("<img></img>").attr("src", file.get("icon")));
                }
            },
            "name": {
                optionName: "File name", id: "name", name: "Name", field: "name",
                sortable: true, editor: BackboneTextEditor
            },
            "username": {
                optionName: "Owner username", id: "username", name: "User", field: "username",
                sortable: true
            },
            "groupname": {
                optionName: "Owner groupname", id: "groupname", name: "Group", field: "groupname",
                sortable: true
            },
            "uid": {
                optionName: "Owner user ID", id: "uid", name: "UID", field: "uid",
                sortable: true, minWidth: 30, maxWidth: 50
            },
            "gid": {
                optionName: "Owner group ID", id: "gid", name: "GID", field: "gid",
                sortable: true, minWidth: 30, maxWidth: 50
            },
            "size": {
                optionName: "File size", id: "size", name: "Size", field: "size",
                sortable: true, minWidth: 30
            },
            "modestr": {
                optionName: "File modes", id: "mode", name: "Mode", field: "modestr",
                sortable: false
            },
            "nmode": {
                optionName: "File mode number", id: "nmode", name: "Numeric mode", field: "mode",
                sortable: false
            },
            "atime": {
                optionName: "Last access time", id: "atime", name: "Access time", field: "atime",
                sortable: true
            },
            "ctime": {
                optionName: "Status change time", id: "ctime", name: "Status ch. time", field: "ctime",
                sortable: true
            },
            "mtime": {
                optionName: "Modification time", id: "mtime", name: "Modif. time", field: "mtime",
                sortable: true
            }
        }
    }
);


/* ******** */

//####assets/js/view.filesystem.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var FileSystemView = Backbone.View.extend({

    _txtPathId: _.uniqueId("fileSystemView"),
    _currentErrors: [],
    _selectedFiles: [],
    _uploadOverlay: null,

    _onPathTextChange: function () {
        var self = this;
        var newDir = $("#" + self._txtPathId).prop("value");

        self._dirTree.openDirectory(newDir);
    },

    _onTreeViewDirectorySelected: function (dir) {
        var self = this;

        // Clear the errors
        self._currentErrors = [];

        // Open the new directory.
        self._filesView.openDirectory(dir);
    },

    // Double click action in the file explorer.
    _onFileDoubleClickAction: function (file) {
        if (file.get("isDir"))
            this._filesView.openDirectory(file);
        else
            window.open("/dl?p=" + encodeURIComponent(file.get("path")), "_self");
    },

    _onDirectorySelected: function (dir) {
        var self = this;

        $("#" + self._txtPathId).val(dir.get("path"));
        self._currentDir = dir;

        // Forward the directory selection to the main view.
        self.trigger("filesystemview:ondirectoryselected", dir);

        self.updateToolbar();

        // Change the last directory option to the new directory.
        self._options.setOptionValue("lastDirectory", dir.get("path"));

        // Change the directory of the upload singleton.
        UploadView.get().setDirectory(dir);
    },

    _onFilesError: function (err) {
        var newErr = new Backbone.Model(err);

        newErr.set("message", err.get("name") + ": " + err.get("error"));

        this.trigger("filesystemview:onerror", newErr);
    },

    _onFilesSelection: function (files) {
        if (files.length == 0)
            $("#lblSelection").text("");
        else if (files.length == 1)
            $("#lblSelection").text(files[0].get("name"));
        else
            $("#lblSelection").text(files.length + " files selected.");

        this._selectedFiles = files;

        this.updateToolbar();
    },

    showUploadOverlay: function (width) {
        this._uploadOverlay = new UploadOverlay({
            el: $("#" + this._uploadOverlayId),
            dir: this._currentDir,
            options: this._options
        });

        this._uploadOverlay.render();
    },

    hideUploadOverlay: function () {
        if (this._uploadOverlay)
            this._uploadOverlay.hide();
    },

    updateToolbar: function () {
        // Update the toolbar, preemptively disable all functions.
        w2ui["fs_view_layout"].get("main").toolbar.disable("btnNew");
        w2ui["fs_view_layout"].get("main").toolbar.disable("btnDelete");
        w2ui["fs_view_layout"].get("main").toolbar.disable("btnDownload");
        w2ui["fs_view_layout"].get("main").toolbar.disable("btnUpload");

        if (this._selectedFiles.length == 1
            && this._selectedFiles[0].get("canRead")
            && !this._selectedFiles[0].get("isDir"))
            w2ui["fs_view_layout"].get("main").toolbar.enable("btnDownload");

        if (this._currentDir.get("canWrite")) {
            w2ui["fs_view_layout"].get("main").toolbar.enable("btnNew");
            w2ui["fs_view_layout"].get("main").toolbar.enable("btnUpload");
        }

        var enableDelete = false;

        _.each(this._selectedFiles, function (selectedFile) {
            enableDelete |= selectedFile.get("canWrite");
        });

        if (enableDelete)
            w2ui["fs_view_layout"].get("main").toolbar.enable("btnDelete");
    },

    downloadSelectedFiles: function () {
        var target = "_blank", ua;

        _.each(this._selectedFiles, function (file) {
            ua = navigator.userAgent;
            if (ua.indexOf("Firefox") != -1 || ua.indexOf("Iceweasel") != -1)
                target = "_new";

            window.open("/dl?p=" + encodeURIComponent(file.get("path")), target);
        });
    },

    deleteSelectedFiles: function () {
        var self = this;

        // The DeletePopup will call the code inside the 'action'
        // callback if the users confirm deletion of the files.
        if (self._options.getOptionValue("confirmDelete")) {
            new DeletePopup({
                options: self._options,
                files: self._selectedFiles,
                confirm: function () {
                    _.each(self._selectedFiles, function (file) {
                        // The wait argument ensures that Backbone will;
                        // wait for the return of the server call before
                        // removing the object from the collection. This
                        // is required since a delete operation might fail and
                        // we want the model to receive the error event
                        // instead of being removed immediately.
                        file.destroy({ wait: true });
                    });

                    self._filesView.clearSelection();
                }
            }).render();
        }
        // No confirmation needed.
        else {
            _.each(self._selectedFiles, function (file) {
                file.destroy({ wait: true });
            });

            self._filesView.clearSelection();
        }
    },

    createDirectory: function (dirname) {
        this._filesView.createDirectory(dirname);
    },

    initialize: function (opts) {
        var self = this;

        self._uploadOverlayId = _.uniqueId("uploadOverlay");
        self._options = opts.options;
        self._sock = opts.sock;

        // Initialize the internal layout
        self.$el.w2layout({
            name: "fs_view_layout",
            padding: 4,
            panels: [
                {
                    type: "left",
                    size: 300,
                    resizable: true
                },
                {
                    type: "main",
                    resizer: 5,
                    resizable: true,
                    toolbar: {
                        items: [
                            { type: "html",  id: "txtPath",
                                html: "<div style='padding: 3px 10px;'>" +
                                    "Path: " +
                                    "<input size='50' id='" + self._txtPathId + "'" +
                                    "       style='padding: 3px; border-radius: 2px; border: 1px solid silver;' />" +
                                    "</div>"
                            },
                            { type: "html", id: "lblSelection" ,
                                html: "<div id='lblSelection' style='padding: 3px 10px;'></div>"
                            },
                            { type: "spacer" },
                            { hint: "New folder",
                                type: "button", id: "btnNewDirectory", icon: "icon-file-alt" },
                            { hint: "Delete file",
                                type: "button", id: "btnDelete", icon: "icon-remove" },
                            { hint: "Download selected file",
                                type: "button", id: "btnDownload", "caption": "Download", icon: "icon-download"
                            },
                            { hint: "Upload a file",
                                type: "drop", id: "btnUpload", "caption": "Upload", icon: "icon-upload",
                                html: "<div id='" + self._uploadOverlayId + "'></div>",
                                overlay: {
                                    width: 400,
                                    height: 400,
                                    onShow: function () { self.showUploadOverlay(); },
                                    onHide: function () { self.hideUploadOverlay(); }
                                }
                            }
                        ],
                        onClick: function (ev) {
                            if (ev.target == "btnDownload")
                                self.downloadSelectedFiles();

                            if (ev.target == "btnDelete")
                                self.deleteSelectedFiles();

                            if (ev.target == "btnNewDirectory")
                                self.createDirectory();
                        }
                    }
                }
            ]
        });

        self._dirTree = new DirTreeView({
            el: w2ui["fs_view_layout"].el("left"),
            options: self._options
        });

        self._filesView = new FilesView({
            el: w2ui["fs_view_layout"].el("main"),
            options: self._options
        });

        // Event wiring.

        self._dirTree.on("dirtreeview:ondirectoryselected", function (dir) {
            self._onTreeViewDirectorySelected.apply(self, [dir]);
        });

        self._filesView.on("filesview:onfileserror", function (err) {
            self._onFilesError.apply(self, [err]);
        });

        self._filesView.on("filesview:ondirectoryselected", function (path) {
            self._onDirectorySelected.apply(self, [path]);
        });

        self._filesView.on("filesview:onfilesselected", function (files) {
            self._onFilesSelection.apply(self, [files]);
        });

        self._filesView.on("filesview:ondoubleclickaction", function (file) {
            self._onFileDoubleClickAction.apply(self, [file]);
        });

        $("#" + self._txtPathId).on("change", function () {
            self._onPathTextChange.apply(self);
        });
    },

    // Refetch the current directory.
    refresh: function () {
        var self = this;

        self._filesView.refresh();
        self._dirTree.refresh();
    },

    resize: function () {
        var self = this;

        self._filesView.resize();

        w2ui["fs_view_layout"].resize();
    }
});

/* ******** */

//####assets/js/view.main.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

function showApropos() {
    w2popup.load({
        width: "640",
        height: "480",
        url: "/apropos"
    });
}

var MainView = Backbone.View.extend({

    _columnsOverlayId: null,
    _optionsOverlayId: null,
    _errorsOverlayId: null,

    _filesystemView: null,
    _errors: [],

    showOptionsOverlay: function () {
        new OptionsOverlay({
            el: $("#" + this._optionsOverlayId),
            options: this._options
        }).render();
    },

    // Display the overlay allowing the selection of the columns that will be
    // displayed in the file manager.
    showColumnsOverlay: function () {
        new ColumnsOverlay({
            el: $("#" + this._columnsOverlayId),
            options: this._options
        }).render();
    },

    showErrorsOverlay: function () {
        new ErrorsOverlay({
            el: $("#" + this._errorsOverlayId),
            errors: this._errors,
            options: this._options
        }).render();
    },

    initialize: function (opts) {
        var self = this;

        self._columnsOverlayId = _.uniqueId("columnsOverlay");
        self._optionsOverlayId = _.uniqueId("optionsOverlay");
        self._errorsOverlayId = _.uniqueId("errorsOverlay");

        self._ka = io.connect(location.host + "/", { rememberTransport: false, transports: ["websocket"] });
        self._ka.on("disconnect", function () {
            new StoppedPopup({
                context: self,
                buttons: [
                    {
                        caption: "Refresh browser",
                        action: function () {
                            location.reload();
                        }
                    },
                    {
                        caption: "Cancel"
                    }
                ]
            }).render();
        });

        self._options = opts.options;

        $("#mainLayout").w2layout({
            name: "fs_layout",
            padding: 4,
            panels: [
                {
                    type: "main",
                    toolbar: {
                        items: [
                            { hint: "Refresh view",
                                type: "button", id: "btnRefresh", icon: "icon-refresh" },
                            { hint: "Displayed columns",
                                type: "drop", id: "btnColumns", caption: "Columns",
                                html: "<div id='" + self._columnsOverlayId + "'></div>",
                                overlay: {
                                    onShow: function () { self.showColumnsOverlay(); }
                                }
                            },
                            { hint: "File manager options",
                                type: "drop", id: "btnOptions", caption: "Options",
                                html: "<div id='" + self._optionsOverlayId + "'></div>",
                                overlay: {
                                    onShow: function () { self.showOptionsOverlay(); }
                                }
                            },
                            { type: 'spacer' },
                            { type: "drop", id: "btnErrors", caption: "Errors",
                                html: "<div id='" + self._errorsOverlayId + "'></div>",
                                overlay: {
                                    width: 400,
                                    onShow: function () { self.showErrorsOverlay(); }
                                },
                                icon: "icon-exclamation-sign"
                            },
                            { type: "html", html:
                                "<a href='http://www.opersys.com'><img alt='opersys logo' src='/images/opersys_land_logo.png' height='24'/></a>" },
                            { type: "html", html:
                                "<a href='javascript:showApropos()'><img alt='copyright icon' src='/images/copyright.png' /></a>" }
                        ],
                        onClick: function (event) {
                            if (event.target == "btnRefresh")
                                self._filesystemView.refresh();
                        }
                    }
                }
            ],
            onResize: function (ev) {
                ev.onComplete = function () {
                    if (self._filesystemView)
                        self._filesystemView.resize();
                };
            }
        });

        this._filesystemView = new FileSystemView({
            el: $(w2ui["fs_layout"].el("main")),
            options: self._options
        });

        this._filesystemView.on("filesystemview:onerror", function (err) {
            var button, toolbar;

            self._errors.push(err);

            console.log("Error: " + err.get("message"));

            // Change the button caption.
            toolbar = w2ui["fs_layout"].get("main").toolbar;
            button = toolbar.get("btnErrors");
            button.caption = "Errors (" + self._errors.length + ")";

            // Change the button color to red to attract attention.
            button.style = "color: red";

            toolbar.refresh();
        });

        this._filesystemView.on("filesystemview:ondirectoryselected", function (path) {
            var button, toolbar;

            self._errors = [];

            // Reset the button caption.
            toolbar = w2ui["fs_layout"].get("main").toolbar;
            button = toolbar.get("btnErrors");
            button.caption = "Errors";

            // Remove the style on the button.
            button.style = "";

            toolbar.refresh();
        });
    }
});

/* ******** */

//####assets/js/view.events.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var EventsView = Backbone.View.extend({

    _columns: [
        { id: "time", name: "Time", field: "time", maxWidth: 60 },
        { id: "msg", name: "Message", field: "msg" }
    ],

    _filesOptions: {
        formatterFactory: {
            getFormatter: function () {
                return function (row, cell, value, col, data) {
                    return data.get(col.field);
                };
            }
        },

        enableColumnReorder: true,
        enableCellNavigation: true,
        forceFitColumns: true
    },

    setEvents: function (ev) {
        var self = this;

        self._fileEvents = ev;

        if (!self._eventGrid)
            self._eventGrid = new Slick.Grid(self.$el, self._fileEvents, self._columns, self._filesOptions);
        else
            self._eventGrid.setData(self._fileEvents);

        self._fileEvents.on("add", function () {
            self._eventGrid.invalidate();
            self._eventGrid.updateRowCount();

            // Immediately resize the canvas.
            self._eventGrid.resizeCanvas();

            self.trigger("eventsview:onnewevent");

            self._eventGrid.render();
        });

        self._fileEvents.on("remove", function () {
            self._eventGrid.invalidate();
            self._eventGrid.updateRowCount();

            // Immediately resize the canvas.
            self._eventGrid.resizeCanvas();

            self.trigger("eventsview:onnewevent");

            self._eventGrid.render();
        });

        self._fileEvents.on("change", function () {
            self._eventGrid.invalidate();
            self._eventGrid.updateRowCount();

            self.trigger("eventsview:onnewevent");

            self._eventGrid.render();
        });
    },

    resize: function () {
        if (this._eventGrid)
            this._eventGrid.resizeCanvas();
    },

    initialize: function (opts) {
        var self = this;

        self._options = opts.options;
    }
});

/* ******** */

//####assets/js/view.files.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var FilesView = Backbone.View.extend({

    _eventInfoId: _.uniqueId("filesview"),
    _eventCount: 0,

    refresh: function () {
        this._filelistView.refresh();
    },

    _onFilesFatalError: function (serverMsg) {
        var self = this;

        new ErrorMessagePopup({
            serverMsg: serverMsg,
            msg: "The backend reported the following error"
        }).render();

        self.openDirectory(self._currentDir);
    },

    _onDisconnected: function () {

    },

    _onFileSelected: function (files) {
        this.trigger("filesview:onfilesselected", files);
    },

    _onDirectorySelected: function () {

    },

    _onDirectoryFetched: function () {
        var self = this;

        self._filelistView.setDirectory(self._files, self._currentDir);

        self.trigger("filesview:ondirectoryselected", self._currentDir);

        if (self._files.getErrors().length > 0) {
            self._files.getErrors().each(function (m) {
                self.trigger("filesview:onfileserror", m);
            });
        }
    },

    _onSortChange: function () {
        var self = this;

        if (self._currentDir)
            self.openDirectory(self._currentDir);
    },

    createDirectory: function () {
        this._filelistView.createDirectory();
    },

    openDirectory: function (dir) {
        var self = this, sortInfo;

        self._currentDir = dir;

        // Must close the collection to free the event source.
        if (self._files)
            self._files.close();

        sortInfo = self._options.getOptionValue("sortInfo");

        self._files = new Files({
            rootPath: self._currentDir.get("path"),
            showHidden: self._options.getOptionValue("showHidden"),
            sortField: sortInfo.field,
            sortDesc: sortInfo.desc,
        });

        self._files.on("error", function (jqXHR, resp, options) {
            self._onFilesFatalError.apply(self, [resp.responseText]);
        });

        self._eventsView.setEvents(self._files.getEvents());

        self._files.fetch({
            reset: true,
            success: function () {
                self._onDirectoryFetched.apply(self);
            }
        });
    },

    clearSelection: function () {
        this._filelistView.clearSelection();
    },

    _setFilesystemEventCount: function (n) {
        $("#" + this._eventInfoId)
            .text("Filesystem events: " + n + " " + Humanize.pluralize(n, "event", "events"));
    },

    _setButton: function(toolbar, btnId, value) {
        _.each(toolbar.items, function (b) {
            if (b.id == btnId) {
                _.each(_.keys(value), function (k) {
                    b[k] = value[k];
                });
            }
        });
    },

    _onMinimizeChange: function () {
        var self = this;
        var panel = w2ui["files_events_view_layout"].get("preview");

        if (self._options.getOptionValue("minimizeEvents")) {
            self._setButton(panel.toolbar, "btnMinimize", {icon: "icon-chevron-up"});
            w2ui["files_events_view_layout"].set("preview", {size: 30});
        } else {
            self._setButton(panel.toolbar, "btnMinimize", {icon: "icon-chevron-down"});
            w2ui["files_events_view_layout"].set("preview", {size: 200});
        }

        panel.toolbar.refresh("btnMinimize");

        self._filelistView.resize();
        self._eventsView.resize();
    },

    initialize: function (opts) {
        var self = this;

        self._options = opts.options;

        // Initialize the internal layout
        self.$el.w2layout({
            name: "files_events_view_layout",
            padding: 4,
            panels: [
                {
                    type: "main"
                },
                {
                    type: "preview",
                    size: 150,
                    toolbar: {
                        items: [
                            { type: "html", html: "<div id=" + self._eventInfoId + "></div>" },
                            { type: "spacer" },
                            { type: "button", id: "btnMinimize", icon: "icon-chevron-down" }
                        ],
                        onClick: function (ev) {
                            if (ev.target == "btnMinimize")
                                self._options.toggleOption("minimizeEvents");
                        }
                    }
                }
            ]
        });

        self._filelistView = new FileListView({
            el: w2ui["files_events_view_layout"].el("main"),
            options: self._options
        });

        self._eventsView = new EventsView({
            el: $(w2ui["files_events_view_layout"].el("preview")).addClass("slickgrid-no-header"),
            options: self._options
        });

        self._filelistView.on("filelistview:onfilesselected", function (files) {
            self._onFileSelected.apply(self, [files]);
        });

        self._filelistView.on("filelistview:ondirectoryloaded", function (dir) {
            self._onDirectorySelected.apply(self, [dir]);
        });

        self._filelistView.on("filelistview:ondoubleclickaction", function (file) {
            self.trigger("filesview:ondoubleclickaction", file);
        });

        self._eventsView.on("eventsview:onnewevent", function (dir) {
            self._eventCount++;
            self._setFilesystemEventCount(self._eventCount);
        });

        self._options.getOption("sortInfo").on("change", function () {
            self._onSortChange.apply(self);
        });

        self._options.getOption("minimizeEvents").on("change", function () {
            self._onMinimizeChange.apply(self);
        });

        self._setFilesystemEventCount(0);
    },

    resize: function () {
        w2ui["files_events_view_layout"].resize();
    }
});

/* ******** */

//####assets/js/fs.js
/*
 * Copyright (C) 2014-2015, Opersys inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var mainView,
    options = new Options();

var resizeWindow = function () {
    $("#mainLayout")
        .width($(window).width())
        .height($(window).height());

    w2ui["fs_layout"].resize();
};

$(document).ready(function () {
    var options = new Options();

    Opentip.lastZIndex = 1000;
    Opentip.styles.warnPopup = {
        extends: "dark",
        hideTriggers: ["closeButton"]
    };

    options.fetch();
    options.initOption("columns", ["icon", "name", "uid", "gid", "size"]);
    options.initOption("showHidden", false);
    options.initOption("sortInfo", { field: "name", desc: false });
    options.initOption("directory", true);
    options.initOption("lastDirectory", "/");
    options.initOption("minimizeEvents", false);
    options.initOption("confirmDelete", true);
    options.initOption("confirmRename", true);

    mainView = new MainView({
        el: $("#mainLayout"),
        options: options
    });

    options.activate();

    $(window).resize(_.debounce(resizeWindow, 100));

    // Reformat the window content.
    resizeWindow();
});