module.exports = require('./posix.node');
